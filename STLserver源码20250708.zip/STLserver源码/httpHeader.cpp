#include "httpHeader.h"


void HTTPHEADER::clear()
{
	Method = {};
	Target = {};
	Version = {};
	Accept = {};
	Accept_Charset = {};
	Accept_Encoding = {};
	Accept_Language = {};
	Accept_Ranges = {};
	Authorization = {};
	Cache_Control = {};
	Connection = {};
	Cookie = {};
	Content_Length = {};
	Content_Type = {};
	Date = {};
	Expect = {};
	From = {};
	Host = {};
	If_Match = {};
	If_Modified_Since = {};
	If_None_Match = {};
	If_Range = {};
	If_Unmodified_Since = {};
	Max_Forwards = {};
	Pragma = {};
	Proxy_Authorization = {};
	Range = {};
	Referer = {};
	TE = {};
	Upgrade = {};
	User_Agent = {};
	Via = {};
	Warning = {};
	Body = {};
	Transfer_Encoding = {};
	HostName = {};
	HostPort = {};


	hasBody = false;

	hasPara = false;

	hasChunk = false;

	hasCompress = false;

	hasDeflate = false;

	hasGzip = false;

	hasIdentity = true;

	expect_continue = false;

	hasJson = false;

	hasXml = false;

	hasX_www_form_urlencoded = false;

	hasMultipart_form_data = false;

}

bool HTTPHEADER::isMethodEmpty()
{
	return Method.empty();
}

bool HTTPHEADER::isTargetEmpty()
{
	return Target.empty();
}

bool HTTPHEADER::isVersionEmpty()
{
	return Version.empty();
}

bool HTTPHEADER::isAcceptEmpty()
{
	return Accept.empty();
}

bool HTTPHEADER::isAccept_CharsetEmpty()
{
	return Accept_Charset.empty();
}

bool HTTPHEADER::isAccept_EncodingEmpty()
{
	return Accept_Encoding.empty();
}

bool HTTPHEADER::isAccept_LanguageEmpty()
{
	return Accept_Language.empty();
}

bool HTTPHEADER::isAccept_RangesEmpty()
{
	return Accept_Ranges.empty();
}

bool HTTPHEADER::isAuthorizationEmpty()
{
	return Authorization.empty();
}

bool HTTPHEADER::isCache_ControlEmpty()
{
	return Cache_Control.empty();
}

bool HTTPHEADER::isConnectionEmpty()
{
	return Connection.empty();
}

bool HTTPHEADER::isCookieEmpty()
{
	return Cookie.empty();
}

bool HTTPHEADER::isContent_LengthEmpty()
{
	return Content_Length.empty();
}

bool HTTPHEADER::isContent_TypeEmpty()
{
	return Content_Type.empty();
}

bool HTTPHEADER::isDateEmpty()
{
	return Date.empty();
}

bool HTTPHEADER::isExpectEmpty()
{
	return Expect.empty();
}

bool HTTPHEADER::isFromEmpty()
{
	return From.empty();
}

bool HTTPHEADER::isHostEmpty()
{
	return Host.empty();
}

bool HTTPHEADER::isIf_MatchEmpty()
{
	return If_Match.empty();
}

bool HTTPHEADER::isIf_Modified_SinceEmpty()
{
	return If_Modified_Since.empty();
}

bool HTTPHEADER::isIf_None_MatchEmpty()
{
	return If_None_Match.empty();
}

bool HTTPHEADER::isIf_RangeEmpty()
{
	return If_Range.empty();
}

bool HTTPHEADER::isIf_Unmodified_SinceEmpty()
{
	return If_Unmodified_Since.empty();
}

bool HTTPHEADER::isMax_ForwardsEmpty()
{
	return Max_Forwards.empty();
}

bool HTTPHEADER::isPragmaEmpty()
{
	return Pragma.empty();
}

bool HTTPHEADER::isProxy_AuthorizationEmpty()
{
	return Proxy_Authorization.empty();
}

bool HTTPHEADER::isRangeEmpty()
{
	return Range.empty();
}

bool HTTPHEADER::isRefererEmpty()
{
	return Referer.empty();
}

bool HTTPHEADER::isTEEmpty()
{
	return TE.empty();
}

bool HTTPHEADER::isUpgradeEmpty()
{
	return Upgrade.empty();
}

bool HTTPHEADER::isUser_AgentEmpty()
{
	return User_Agent.empty();
}

bool HTTPHEADER::isViaEmpty()
{
	return Via.empty();
}

bool HTTPHEADER::isWarningEmpty()
{
	return Warning.empty();
}

bool HTTPHEADER::isBodyEmpty()
{
	return Body.empty();
}

bool HTTPHEADER::isTransfer_EncodingEmpty()
{
	return Transfer_Encoding.empty();
}

bool HTTPHEADER::getBody()
{
	return hasBody;
}

bool HTTPHEADER::getPara()
{
	return hasPara;
}

bool HTTPHEADER::getChunk()
{
	return hasChunk;
}

bool HTTPHEADER::getCompress()
{
	return hasCompress;
}

bool HTTPHEADER::getDeflate()
{
	return hasDeflate;
}

bool HTTPHEADER::getGzip()
{
	return hasGzip;
}

bool HTTPHEADER::getIdentity()
{
	return hasIdentity;
}

bool HTTPHEADER::getExpect_continue()
{
	return expect_continue;
}

bool HTTPHEADER::getJson()
{
	return hasJson;
}

bool HTTPHEADER::getXml()
{
	return hasXml;
}

bool HTTPHEADER::getX_www_form_urlencoded()
{
	return hasX_www_form_urlencoded;
}

bool HTTPHEADER::getMultipart_form_data()
{
	return hasMultipart_form_data;
}





























void HTTPHEADER::setMethod(const char* begin, const char* end)
{
	Method = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setMethod(const char* begin, const unsigned int len)
{
	Method = { begin ,len };
}

void HTTPHEADER::setTarget(const char* begin, const char* end)
{
	Target = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setTarget(const char* begin, const unsigned int len)
{
	Target = { begin ,len };
}

void HTTPHEADER::setVersion(const char* begin, const char* end)
{
	Version = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setVersion(const char* begin, const unsigned int len)
{
	Version = { begin ,len };
}

void HTTPHEADER::setAccept(const char* begin, const char* end)
{
	Accept = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setAccept(const char* begin, const unsigned int len)
{
	Accept = { begin ,len };
}

void HTTPHEADER::setAccept_Charset(const char* begin, const char* end)
{
	Accept_Charset= { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setAccept_Charset(const char* begin, const unsigned int len)
{
	Accept_Charset= { begin ,len };
}

void HTTPHEADER::setAccept_Encoding(const char* begin, const char* end)
{
	Accept_Encoding = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setAccept_Encoding(const char* begin, const unsigned int len)
{
	Accept_Encoding = { begin ,len };
}

void HTTPHEADER::setAccept_Language(const char* begin, const char* end)
{
	Accept_Language = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setAccept_Language(const char* begin, const unsigned int len)
{
	Accept_Language = { begin ,len };
}

void HTTPHEADER::setAccept_Ranges(const char* begin, const char* end)
{
	Accept_Ranges = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setAccept_Ranges(const char* begin, const unsigned int len)
{
	Accept_Ranges = { begin ,len };
}

void HTTPHEADER::setAuthorization(const char* begin, const char* end)
{
	Authorization = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setAuthorization(const char* begin, const unsigned int len)
{
	Authorization = { begin ,len };
}

void HTTPHEADER::setCache_Control(const char* begin, const char* end)
{
	Cache_Control = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setCache_Control(const char* begin, const unsigned int len)
{
	Cache_Control = { begin ,len };
}

void HTTPHEADER::setConnection(const char* begin, const char* end)
{
	Connection = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setConnection(const char* begin, const unsigned int len)
{
	Connection = { begin ,len };
}

void HTTPHEADER::setCookie(const char* begin, const char* end)
{
	Cookie = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setCookie(const char* begin, const unsigned int len)
{
	Cookie = { begin ,len };
}

void HTTPHEADER::setContent_Length(const char* begin, const char* end)
{
	Content_Length = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setContent_Length(const char* begin, const unsigned int len)
{
	Content_Length = { begin ,len };
}

void HTTPHEADER::setContent_Type(const char* begin, const char* end)
{
	Content_Type = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setContent_Type(const char* begin, const unsigned int len)
{
	Content_Type = { begin ,len };
}

void HTTPHEADER::setDate(const char* begin, const char* end)
{
	Date = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setDate(const char* begin, const unsigned int len)
{
	Date = { begin ,len };
}

void HTTPHEADER::setExpect(const char* begin, const char* end)
{
	Expect = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setExpect(const char* begin, const unsigned int len)
{
	Expect = { begin ,len };
}

void HTTPHEADER::setFrom(const char* begin, const char* end)
{
	From = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setFrom(const char* begin, const unsigned int len)
{
	From = { begin ,len };
}

void HTTPHEADER::setHost(const char* begin, const char* end)
{
	Host = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setHost(const char* begin, const unsigned int len)
{
	Host = { begin ,len };
}

void HTTPHEADER::setIf_Match(const char* begin, const char* end)
{
	If_Match = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setIf_Match(const char* begin, const unsigned int len)
{
	If_Match = { begin ,len };
}

void HTTPHEADER::setIf_Modified_Since(const char* begin, const char* end)
{
	If_Modified_Since = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setIf_Modified_Since(const char* begin, const unsigned int len)
{
	If_Modified_Since = { begin ,len };
}

void HTTPHEADER::setIf_None_Match(const char* begin, const char* end)
{
	If_None_Match = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setIf_None_Match(const char* begin, const unsigned int len)
{
	If_None_Match = { begin ,len };
}

void HTTPHEADER::setIf_Range(const char* begin, const char* end)
{
	If_Range = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setIf_Range(const char* begin, const unsigned int len)
{
	If_Range = { begin ,len };
}

void HTTPHEADER::setIf_Unmodified_Since(const char* begin, const char* end)
{
	If_Unmodified_Since = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setIf_Unmodified_Since(const char* begin, const unsigned int len)
{
	If_Unmodified_Since = { begin ,len };
}

void HTTPHEADER::setMax_Forwards(const char* begin, const char* end)
{
	Max_Forwards = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setMax_Forwards(const char* begin, const unsigned int len)
{
	Max_Forwards = { begin ,len };
}

void HTTPHEADER::setPragma(const char* begin, const char* end)
{
	Pragma = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setPragma(const char* begin, const unsigned int len)
{
	Pragma = { begin ,len };
}

void HTTPHEADER::setProxy_Authorization(const char* begin, const char* end)
{
	Proxy_Authorization = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setProxy_Authorization(const char* begin, const unsigned int len)
{
	Proxy_Authorization = { begin ,len };
}

void HTTPHEADER::setRange(const char* begin, const char* end)
{
	Range = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setRange(const char* begin, const unsigned int len)
{
	Range = { begin ,len };
}

void HTTPHEADER::setReferer(const char* begin, const char* end)
{
	Referer = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setReferer(const char* begin, const unsigned int len)
{
	Referer = { begin ,len };
}

void HTTPHEADER::setTE(const char* begin, const char* end)
{
	TE = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setTE(const char* begin, const unsigned int len)
{
	TE = { begin ,len };
}

void HTTPHEADER::setUpgrade(const char* begin, const char* end)
{
	Upgrade = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setUpgrade(const char* begin, const unsigned int len)
{
	Upgrade= { begin ,len };
}

void HTTPHEADER::setUser_Agent(const char* begin, const char* end)
{
	User_Agent = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setUser_Agent(const char* begin, const unsigned int len)
{
	User_Agent = { begin ,len };
}

void HTTPHEADER::setVia(const char* begin, const char* end)
{
	Via = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setVia(const char* begin, const unsigned int len)
{
	Via = { begin ,len };
}

void HTTPHEADER::setWarning(const char* begin, const char* end)
{
	Warning = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setWarning(const char* begin, const unsigned int len)
{
	Warning = { begin ,len };
}

void HTTPHEADER::setBody(const char* begin, const char* end)
{
	Body = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setBody(const char* begin, const unsigned int len)
{
	Body = { begin ,len };
}

void HTTPHEADER::setTransfer_Encoding(const char* begin, const char* end)
{
	Transfer_Encoding = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setTransfer_Encoding(const char* begin, const unsigned int len)
{
	Transfer_Encoding = { begin ,len };
}

void HTTPHEADER::setHostName(const char* begin, const char* end)
{
	HostName = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setHostName(const char* begin, const unsigned int len)
{
	HostName = { begin ,len };
}

void HTTPHEADER::setHostPort(const char* begin, const char* end)
{
	HostPort = { begin ,std::distance(begin,end) };
}

void HTTPHEADER::setHostPort(const char* begin, const unsigned int len)
{
	HostPort = { begin ,len };
}

void HTTPHEADER::setBody(bool value)
{
	hasBody = value;
}

void HTTPHEADER::setPara(bool value)
{
	hasPara = value;
}

void HTTPHEADER::setChunk(bool value)
{
	hasChunk = value;
}

void HTTPHEADER::setCompress(bool value)
{
	hasCompress = value;
}

void HTTPHEADER::setDeflate(bool value)
{
	hasDeflate = value;
}

void HTTPHEADER::setGzip(bool value)
{
	hasGzip = value;
}

void HTTPHEADER::setIdentity(bool value)
{
	hasIdentity = value;
}

void HTTPHEADER::setExpect_continue(bool value)
{
	expect_continue = true;
}

void HTTPHEADER::setJson(bool value)
{
	hasJson = value;
}

void HTTPHEADER::setXml(bool value)
{
	hasXml = value;
}

void HTTPHEADER::setX_www_form_urlencoded(bool value)
{
	hasX_www_form_urlencoded = value;
}

void HTTPHEADER::setMultipart_form_data(bool value)
{
	hasMultipart_form_data = value;
}

std::string_view HTTPHEADER::getMethodView()
{
	return Method;
}

std::string_view HTTPHEADER::getTargetView()
{
	return Target;
}

std::string_view HTTPHEADER::getVersionView()
{
	return Version;
}

std::string_view HTTPHEADER::getAcceptView()
{
	return Accept;
}

std::string_view HTTPHEADER::getAccept_CharsetView()
{
	return Accept_Charset;
}

std::string_view HTTPHEADER::getAccept_EncodingView()
{
	return Accept_Encoding;
}

std::string_view HTTPHEADER::getAccept_LanguageView()
{
	return Accept_Language;
}

std::string_view HTTPHEADER::getAccept_RangesView()
{
	return Accept_Ranges;
}

std::string_view HTTPHEADER::getAuthorizationView()
{
	return Authorization;
}

std::string_view HTTPHEADER::getCache_ControlView()
{
	return Cache_Control;
}

std::string_view HTTPHEADER::getConnectionView()
{
	return Connection;
}

std::string_view HTTPHEADER::getCookieView()
{
	return Cookie;
}

std::string_view HTTPHEADER::getContent_LengthView()
{
	return Content_Length;
}

std::string_view HTTPHEADER::getContent_TypeView()
{
	return Content_Type;
}

std::string_view HTTPHEADER::getDateView()
{
	return Date;
}

std::string_view HTTPHEADER::getExpectView()
{
	return Expect;
}

std::string_view HTTPHEADER::getFromView()
{
	return From;
}

std::string_view HTTPHEADER::getHostView()
{
	return Host;
}

std::string_view HTTPHEADER::getIf_MatchView()
{
	return If_Match;
}

std::string_view HTTPHEADER::getIf_Modified_SinceView()
{
	return If_Modified_Since;
}

std::string_view HTTPHEADER::getIf_None_MatchView()
{
	return If_None_Match;
}

std::string_view HTTPHEADER::getIf_RangeView()
{
	return If_Range;
}

std::string_view HTTPHEADER::getIf_Unmodified_SinceView()
{
	return If_Unmodified_Since;
}

std::string_view HTTPHEADER::getMax_ForwardsView()
{
	return Max_Forwards;
}

std::string_view HTTPHEADER::getPragmaView()
{
	return Pragma;
}

std::string_view HTTPHEADER::getProxy_AuthorizationView()
{
	return Proxy_Authorization;
}

std::string_view HTTPHEADER::getRangeView()
{
	return Range;
}

std::string_view HTTPHEADER::getRefererView()
{
	return Referer;
}

std::string_view HTTPHEADER::getTEView()
{
	return TE;
}

std::string_view HTTPHEADER::getUpgradeView()
{
	return Upgrade;
}

std::string_view HTTPHEADER::getUser_AgentView()
{
	return User_Agent;
}

std::string_view HTTPHEADER::getViaView()
{
	return Via;
}

std::string_view HTTPHEADER::getWarningView()
{
	return Warning;
}

std::string_view HTTPHEADER::getBodyView()
{
	return Body;
}

std::string_view HTTPHEADER::getTransfer_EncodingView()
{
	return Transfer_Encoding;
}



