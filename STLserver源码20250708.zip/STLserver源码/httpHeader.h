#pragma once


#include<string_view>




//�洢http Header��Ϣ����

struct HTTPHEADER
{
	HTTPHEADER() = default;

	//���״̬
	void clear();

	bool isMethodEmpty();

	bool isTargetEmpty();

	bool isVersionEmpty();
		
	bool isAcceptEmpty();

	bool isAccept_CharsetEmpty();
	
	bool isAccept_EncodingEmpty();
	
	bool isAccept_LanguageEmpty();

	bool isAccept_RangesEmpty();
	
	bool isAuthorizationEmpty();

	bool isCache_ControlEmpty();
	
	bool isConnectionEmpty();
	
	bool isCookieEmpty();

	bool isContent_LengthEmpty();

	bool isContent_TypeEmpty();
	
	bool isDateEmpty();
	
	bool isExpectEmpty();

	bool isFromEmpty();

	bool isHostEmpty();

	bool isIf_MatchEmpty();
	
	bool isIf_Modified_SinceEmpty();

	bool isIf_None_MatchEmpty();
	
	bool isIf_RangeEmpty();

	bool isIf_Unmodified_SinceEmpty();

	bool isMax_ForwardsEmpty();

	bool isPragmaEmpty();

	bool isProxy_AuthorizationEmpty();
	
	bool isRangeEmpty();
	
	bool isRefererEmpty();
	
	bool isTEEmpty();

	bool isUpgradeEmpty();

	bool isUser_AgentEmpty();
	
	bool isViaEmpty();

	bool isWarningEmpty();
	
	bool isBodyEmpty();

	bool isTransfer_EncodingEmpty();

	bool getBody();

	bool getPara();

	bool getChunk();

	bool getCompress();

	bool getDeflate();

	bool getGzip();

	bool getIdentity();

	bool getExpect_continue();

	bool getJson();

	bool getXml();

	bool getX_www_form_urlencoded();

	bool getMultipart_form_data();












	void setMethod(const char* begin, const char* end);

	void setMethod(const char* begin, const unsigned int len);

	void setTarget(const char* begin, const char* end);

	void setTarget(const char* begin, const unsigned int len);

	void setVersion(const char* begin, const char* end);

	void setVersion(const char* begin, const unsigned int len);
	
	void setAccept(const char* begin, const char* end);

	void setAccept(const char* begin, const unsigned int len);

	void setAccept_Charset(const char* begin, const char* end);

	void setAccept_Charset(const char* begin, const unsigned int len);
	
	void setAccept_Encoding(const char* begin, const char* end);

	void setAccept_Encoding(const char* begin, const unsigned int len);

	void setAccept_Language(const char* begin, const char* end);

	void setAccept_Language(const char* begin, const unsigned int len);
	
	void setAccept_Ranges(const char* begin, const char* end);

	void setAccept_Ranges(const char* begin, const unsigned int len);

	void setAuthorization(const char* begin, const char* end);

	void setAuthorization(const char* begin, const unsigned int len);

	void setCache_Control(const char* begin, const char* end);

	void setCache_Control(const char* begin, const unsigned int len);

	void setConnection(const char* begin, const char* end);

	void setConnection(const char* begin, const unsigned int len);

	void setCookie(const char* begin, const char* end);

	void setCookie(const char* begin, const unsigned int len);

	void setContent_Length(const char* begin, const char* end);

	void setContent_Length(const char* begin, const unsigned int len);
	
	void setContent_Type(const char* begin, const char* end);

	void setContent_Type(const char* begin, const unsigned int len);
	
	void setDate(const char* begin, const char* end);

	void setDate(const char* begin, const unsigned int len);
	
	void setExpect(const char* begin, const char* end);

	void setExpect(const char* begin, const unsigned int len);

	void setFrom(const char* begin, const char* end);

	void setFrom(const char* begin, const unsigned int len);

	void setHost(const char* begin, const char* end);

	void setHost(const char* begin, const unsigned int len);
	
	void setIf_Match(const char* begin, const char* end);

	void setIf_Match(const char* begin, const unsigned int len);

	void setIf_Modified_Since(const char* begin, const char* end);

	void setIf_Modified_Since(const char* begin, const unsigned int len);

	void setIf_None_Match(const char* begin, const char* end);

	void setIf_None_Match(const char* begin, const unsigned int len);

	void setIf_Range(const char* begin, const char* end);

	void setIf_Range(const char* begin, const unsigned int len);
	
	void setIf_Unmodified_Since(const char* begin, const char* end);

	void setIf_Unmodified_Since(const char* begin, const unsigned int len);
	
	void setMax_Forwards(const char* begin, const char* end);

	void setMax_Forwards(const char* begin, const unsigned int len);

	void setPragma(const char* begin, const char* end);

	void setPragma(const char* begin, const unsigned int len);

	void setProxy_Authorization(const char* begin, const char* end);

	void setProxy_Authorization(const char* begin, const unsigned int len);
	
	void setRange(const char* begin, const char* end);

	void setRange(const char* begin, const unsigned int len);
	
	void setReferer(const char* begin, const char* end);

	void setReferer(const char* begin, const unsigned int len);

	void setTE(const char* begin, const char* end);

	void setTE(const char* begin, const unsigned int len);

	void setUpgrade(const char* begin, const char* end);

	void setUpgrade(const char* begin, const unsigned int len);
	
	void setUser_Agent(const char* begin, const char* end);

	void setUser_Agent(const char* begin, const unsigned int len);

	void setVia(const char* begin, const char* end);

	void setVia(const char* begin, const unsigned int len);

	void setWarning(const char* begin, const char* end);

	void setWarning(const char* begin, const unsigned int len);
	
	void setBody(const char* begin, const char* end);

	void setBody(const char* begin, const unsigned int len);

	void setTransfer_Encoding(const char* begin, const char* end);

	void setTransfer_Encoding(const char* begin, const unsigned int len);
	
	void setHostName(const char* begin, const char* end);

	void setHostName(const char* begin, const unsigned int len);
	
	void setHostPort(const char* begin, const char* end);

	void setHostPort(const char* begin, const unsigned int len);

	void setBody(bool value);
	
	void setPara(bool value);

	void setChunk(bool value);

	void setCompress(bool value);

	void setDeflate(bool value);

	void setGzip(bool value);

	void setIdentity(bool value);

	void setExpect_continue(bool value);

	void setJson(bool value);

	void setXml(bool value);

	void setX_www_form_urlencoded(bool value);

	void setMultipart_form_data(bool value);









	std::string_view getMethodView();

	std::string_view getTargetView();

	std::string_view getVersionView();

	std::string_view getAcceptView();

	std::string_view getAccept_CharsetView();

	std::string_view getAccept_EncodingView();

	std::string_view getAccept_LanguageView();

	std::string_view getAccept_RangesView();

	std::string_view getAuthorizationView();

	std::string_view getCache_ControlView();

	std::string_view getConnectionView();

	std::string_view getCookieView();

	std::string_view getContent_LengthView();

	std::string_view getContent_TypeView();

	std::string_view getDateView();

	std::string_view getExpectView();

	std::string_view getFromView();

	std::string_view getHostView();

	std::string_view getIf_MatchView();

	std::string_view getIf_Modified_SinceView();

	std::string_view getIf_None_MatchView();

	std::string_view getIf_RangeView();

	std::string_view getIf_Unmodified_SinceView();

	std::string_view getMax_ForwardsView();

	std::string_view getPragmaView();

	std::string_view getProxy_AuthorizationView();

	std::string_view getRangeView();

	std::string_view getRefererView();

	std::string_view getTEView();

	std::string_view getUpgradeView();

	std::string_view getUser_AgentView();

	std::string_view getViaView();

	std::string_view getWarningView();

	std::string_view getBodyView();

	std::string_view getTransfer_EncodingView();




























private:

	std::string_view Method{};
	std::string_view Target{};
	std::string_view Version{};
	std::string_view Accept{};
	std::string_view Accept_Charset{};
	std::string_view Accept_Encoding{};
	std::string_view Accept_Language{};
	std::string_view Accept_Ranges{};
	std::string_view Authorization{};
	std::string_view Cache_Control{};
	std::string_view Connection{};
	std::string_view Cookie{};
	std::string_view Content_Length{};
	std::string_view Content_Type{};
	std::string_view Date{};
	std::string_view Expect{};
	std::string_view From{};
	std::string_view Host{};
	std::string_view If_Match{};
	std::string_view If_Modified_Since{};
	std::string_view If_None_Match{};
	std::string_view If_Range{};
	std::string_view If_Unmodified_Since{};
	std::string_view Max_Forwards{};
	std::string_view Pragma{};
	std::string_view Proxy_Authorization{};
	std::string_view Range{};
	std::string_view Referer{};
	std::string_view TE{};
	std::string_view Upgrade{};
	std::string_view User_Agent{};
	std::string_view Via{};
	std::string_view Warning{};
	std::string_view Body{};
	std::string_view Transfer_Encoding{};
	std::string_view HostName{};
	std::string_view HostPort{};
	

	/////////////////////////////////////

	bool hasBody{ false };                     //�Ƿ���body

	bool hasPara{ false };                     //url���Ƿ������

	bool hasChunk{ false };                    //�Ƿ���Chunk�����ʽ

	bool hasCompress{ false };                //�Ƿ�֧��LZWѹ��

	bool hasDeflate{ false };                 //�Ƿ�֧��zlibѹ��

	bool hasGzip{ false };                    //�Ƿ�֧��LZ77ѹ��

	bool hasIdentity{ true };                 //�Ƿ񲻽����κ�ѹ����ֿ飬����ԭʼ����

	bool expect_continue{ false };

	bool hasJson{ false };                     //�����ʽ�Ƿ���json

	bool hasXml{ false };                      //�����ʽ�Ƿ���XML

	bool hasX_www_form_urlencoded{ false };         //�����ʽ�Ƿ���x-www-form-urlencoded

	bool hasMultipart_form_data{ false };          //�����ʽ�Ƿ���multipart/form-data
};




