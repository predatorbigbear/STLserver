#include "MiddleCenter.h"



MiddleCenter::MiddleCenter()
{
	m_unlockFun.reset(new std::function<void()>(std::bind(&MiddleCenter::unlock, this)));
}

MiddleCenter::~MiddleCenter()
{
	if (m_initSql)
		freeMysql();
}






void MiddleCenter::setLog(const char * logFileName, std::shared_ptr<IOcontextPool> ioPool , bool& success, const int overTime , const int bufferSize, const int bufferNum)
{
	//std::lock_guard<std::mutex>l1{ m_mutex };
	m_mutex.lock();
	try
	{
		if (!logFileName)
			throw std::runtime_error("logFileName is invaild");
		if (!ioPool)
			throw std::runtime_error("ioPool is invaild");
		if (overTime <= 0)
			throw std::runtime_error("overTime is invaild");
		if (bufferSize <= 0)
			throw std::runtime_error("bufferSize is invaild");
		if (bufferNum <= 0)
			throw std::runtime_error("bufferNum is invaild");

		if (!m_hasSetLog)
		{
			m_logPool.reset(new LOGPOOL(logFileName , ioPool, success , overTime, bufferSize, bufferNum));
			if (!success)
				throw std::runtime_error("create LOGPOOL fail");
			m_hasSetLog = true;
		}
		success = true;
		m_mutex.unlock();
	}
	catch (const std::exception &e)
	{
		cout << e.what() << "  ,please restart server\n";
		success = false;
		m_mutex.unlock();
	}
}



void MiddleCenter::setHTTPServer(std::shared_ptr<IOcontextPool> ioPool, bool& success, const std::string &tcpAddress, const std::string &doc_root, const int socketNum, const int timeOut)
{
	//std::lock_guard<std::mutex>l1{ m_mutex };
	m_mutex.lock();
	if (!success)
	{
		m_mutex.unlock();
		return;
	}
	try
	{
		if (socketNum <= 0)
			throw std::runtime_error("socketNum is invaild");
		if(doc_root.empty() || *(doc_root.rbegin()) == '/')
			throw std::runtime_error("doc_root is invaild");
		if(!fs::exists(doc_root))
			throw std::runtime_error("doc_root is invaild path");
		if (!m_hasSetListener && m_logPool)
		{
			m_listener.reset(new listener(ioPool, m_multiSqlReadSWPoolMaster,
				m_multiRedisReadPoolMaster ,m_multiRedisWritePoolMaster,
				m_multiSqlWriteSWPoolMaster,tcpAddress, doc_root, m_logPool, socketNum, timeOut, m_checkSecond, m_timeWheel
				));
			m_hasSetListener = true;
		}
		m_mutex.unlock();
	}
	catch (const std::exception &e)
	{
		cout << e.what() << "  ,please restart server\n";
		success = false;
		m_mutex.unlock();
	}
}



void MiddleCenter::setMultiRedisRead(std::shared_ptr<IOcontextPool> ioPool, bool& success, const std::string & redisIP, const unsigned int redisPort, const unsigned int bufferNum,
	const unsigned int memorySize, const unsigned int outRangeMaxSize, const unsigned int commandSize)
{
	try
	{
		m_mutex.lock();
		if (!success)
		{
			m_mutex.unlock();
			return;
		}
		m_multiRedisReadPoolMaster.reset(new MULTIREDISREADPOOL(ioPool, m_logPool, m_unlockFun, redisIP, redisPort, bufferNum, memorySize, outRangeMaxSize, commandSize));
		success = true;
	}
	catch (const std::exception& e)
	{
		cout << e.what() << "   ,please restart server\n";
		success = false;
		m_mutex.unlock();
	}
}


void MiddleCenter::setMultiRedisWrite(std::shared_ptr<IOcontextPool> ioPool, bool& success, const std::string & redisIP, const unsigned int redisPort, const unsigned int bufferNum,
	const unsigned int memorySize, const unsigned int outRangeMaxSize, const unsigned int commandSize)
{
	try
	{
		m_mutex.lock();
		if (!success)
		{
			m_mutex.unlock();
			return;
		}
		m_multiRedisWritePoolMaster.reset(new MULTIREDISWRITEPOOL(ioPool, m_unlockFun, redisIP, redisPort, bufferNum, memorySize, outRangeMaxSize, commandSize));
		success = true;
	}
	catch (const std::exception& e)
	{
		cout << e.what() << "   ,please restart server\n";
		success = false;
		m_mutex.unlock();
	}
}



void MiddleCenter::setMultiSqlReadSW(std::shared_ptr<IOcontextPool> ioPool, bool& success, const std::string & SQLHOST, const std::string & SQLUSER, const std::string & SQLPASSWORD,
	const std::string & SQLDB, const std::string & SQLPORT, const unsigned int commandMaxSize, const int bufferNum)
{
	try
	{
		m_mutex.lock();
		if (!success)
		{
			m_mutex.unlock();
			return;
		}
		m_multiSqlReadSWPoolMaster.reset(new MULTISQLREADSWPOOL(ioPool, m_unlockFun, SQLHOST, SQLUSER, SQLPASSWORD, SQLDB, SQLPORT, m_logPool, commandMaxSize, bufferNum));
		success = true;
	}
	catch (const std::exception& e)
	{
		cout << e.what() << "   ,please restart server\n";
		success = false;
		m_mutex.unlock();
	}
}



void MiddleCenter::setMultiSqlWriteSW(std::shared_ptr<IOcontextPool> ioPool, bool& success, const std::string & SQLHOST, const std::string & SQLUSER, const std::string & SQLPASSWORD,
	const std::string & SQLDB, const std::string & SQLPORT, const unsigned int commandMaxSize, const int bufferNum)
{
	try
	{
		m_mutex.lock();
		if (!success)
		{
			m_mutex.unlock();
			return;
		}
		m_multiSqlWriteSWPoolMaster.reset(new MULTISQLWRITESWPOOL(ioPool, m_unlockFun, SQLHOST, SQLUSER, SQLPASSWORD, SQLDB, SQLPORT, m_logPool, commandMaxSize, bufferNum));
		success = true;
	}
	catch (const std::exception& e)
	{
		cout << e.what() << "   ,please restart server\n";
		success = false;
		m_mutex.unlock();
	}
}


//����mysql���ļ����ڵ���mysql C api֮ǰ����
void MiddleCenter::initMysql(bool& success)
{
	m_mutex.lock();
	if (!success)
	{
		m_mutex.unlock();
		return;
	}
	if (mysql_library_init(0, NULL, NULL)) //�������̶߳�MYSQL C API����֮ǰ����
	{
		std::cout << "mysql_library_init error\n";
		success = false;
		m_initSql = true;
		m_mutex.unlock();
		return;
	}
	success = true;
	m_mutex.unlock();
}

void MiddleCenter::freeMysql()
{
	mysql_library_end();
	m_initSql = false;
}

void MiddleCenter::unlock()
{
	std::this_thread::sleep_for(std::chrono::seconds(1));
	m_mutex.unlock();
}



void MiddleCenter::setTimeWheel(std::shared_ptr<IOcontextPool> ioPool, bool& success, const unsigned int checkSecond, const unsigned int wheelNum, const unsigned int everySecondFunctionNumber)
{
	try
	{
		m_checkSecond = checkSecond;
		m_timeWheel.reset(new STLTimeWheel(ioPool->getIoNext(), checkSecond, wheelNum, everySecondFunctionNumber));
		success = true;
	}
	catch (const std::exception& e)
	{
		success = false;
	}
}
