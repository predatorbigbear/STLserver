#pragma once


#include "httpService.h"
#include "FixedHttpServicePool.h"
#include "LOG.h"
#include "fixedTemplateSafeList.h"
#include "logPool.h"
#include "multiSqlReadSWPool.h"
#include "multiRedisReadPool.h"
#include "multiRedisWritePool.h"
#include "multiSqlWriteSWPool.h"
#include "STLTimeWheel.h"

#include<atomic>

// 

struct listener 
{
	listener(std::shared_ptr<IOcontextPool> ioPool,
		std::shared_ptr<MULTISQLREADSWPOOL>multiSqlReadSWPoolMaster,
		std::shared_ptr<MULTIREDISREADPOOL>multiRedisReadPoolMaster,
		std::shared_ptr<MULTIREDISWRITEPOOL>multiRedisWritePoolMaster, std::shared_ptr<MULTISQLWRITESWPOOL>multiSqlWriteSWPoolMaster,
		const std::string &tcpAddress, const std::string &doc_root , std::shared_ptr<LOGPOOL> logPool ,
		const std::shared_ptr<std::unordered_map<std::string_view, std::string>>fileMap,
		const int socketNum , const int timeOut, const unsigned int checkSecond, std::shared_ptr<STLTimeWheel> timeWheel
		);



private:
	std::shared_ptr<io_context> m_ioc{};
	std::unique_ptr<boost::asio::ip::tcp::acceptor> m_acceptor{};
	std::unique_ptr<boost::asio::ip::tcp::endpoint>m_endpoint{};
	const std::string &m_doc_root;
	const std::string &m_tcpAddress;
	std::string m_tempAddress;
	boost::system::error_code m_err;
	int m_sendSize{};

	int m_size{};

	int temp{};
	

	std::atomic<bool> m_startAccept{ true };
	
	
	std::shared_ptr<IOcontextPool> m_ioPool{};
	
	
	std::unique_ptr<FixedHTTPSERVICEPOOL> m_httpServicePool{};

	std::unique_ptr<FIXEDTEMPLATESAFELIST<std::shared_ptr<HTTPSERVICE>>> m_httpServiceList{};

	std::shared_ptr<std::function<void(std::shared_ptr<HTTPSERVICE>)>>m_clearFunction{};

	std::shared_ptr<std::function<void()>>m_startFunction{};

	std::shared_ptr<std::function<void()>>m_startcheckTime{};

	std::unique_ptr<boost::asio::steady_timer> m_timeOutTimer{};       //  ������ڼ�鳬ʱ����Ҫ����

	std::shared_ptr<std::unordered_map<std::string_view, std::string>>m_fileMap{};


	std::shared_ptr<LOG> m_log{};

	std::shared_ptr<LOGPOOL> m_logPool{};

	std::shared_ptr<MULTISQLWRITESWPOOL>m_multiSqlWriteSWPoolMaster{};         //   �����ݿ�д�����ӳ�
	std::shared_ptr<MULTISQLREADSWPOOL>m_multiSqlReadSWPoolMaster{};           //   �����ݿ��ȡ���ӳ�

	std::shared_ptr<MULTIREDISWRITEPOOL>m_multiRedisWritePoolMaster{};         //   ��redisд�����ӳ�
	std::shared_ptr<MULTIREDISREADPOOL>m_multiRedisReadPoolMaster{};           //   ��redis��ȡ���ӳ�

	std::shared_ptr<STLTimeWheel>m_timeWheel{};                                 //ʱ���ֶ�ʱ��


	int m_socketNum{};

	int m_timeOut{};

	//ʱ���ּ����
	unsigned int m_checkTurn{};

private:
	void resetEndpoint();

	void resetAcceptor();

	void openAcceptor();

	void bindAcceptor();

	void listenAcceptor();

	void startAccept();

	void handleStartAccept(std::shared_ptr<HTTPSERVICE> httpServiceTemp,const boost::system::error_code &err);

	void getBackHTTPSERVICE(std::shared_ptr<HTTPSERVICE> tempHs);

	void restartAccept();

	void notifySocketPool();

	void startRun();

	void reAccept();

	void checkTimeOut();
};