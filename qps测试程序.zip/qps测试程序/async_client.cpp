#include "async_client.hpp"
#include <iostream>


std::atomic<int>num{};
std::atomic<bool>check{ false };

AsyncClient::AsyncClient(boost::asio::io_context& io,
    const std::string& host,
    const std::string& port,
    const int testApi
)
    : socket_(io), resolver_(io), host_(host), port_(port),
    read_buffer_(1024) 
{
    switch(testApi)
    {
    case 1:             
        write_data_ = "POST /4 HTTP/1.1\r\nHost:192.168.80.128:8085\r\nContent-Type:application/x-www-form-urlencoded\r\nContent-Length:0\r\n\r\n";
        answer_data_ = "HTTP/1.0 200 OK\r\nAccess-Control-Allow-Origin:*\r\nContent-length:24\r\n\r\n{\"result\":\"hello_world\"}";
        break;
    case 2:             //testMakeJson         
        write_data_ = "POST /19 HTTP/1.1\r\nHost:192.168.80.128:8085\r\nContent-Type:application/x-www-form-urlencoded\r\nContent-Length:17\r\n\r\njsonType=keyValue";
        answer_data_ = "HTTP/1.0 200 OK\r\nAccess-Control-Allow-Origin:*\r\nContent-length:17\r\n\r\n{\"key1\":\"value1\"}";
    case 3:           //testMakeJson   
        write_data_ = "POST /19 HTTP/1.1\r\nHost:192.168.80.128:8085\r\nContent-Type:application/x-www-form-urlencoded\r\nContent-Length:20\r\n\r\njsonType=doubleValue";
        answer_data_ = "HTTP/1.0 200 OK\r\nAccess-Control-Allow-Origin:*\r\nContent-length:34\r\n\r\n{\"key1\":1.001000,\"key2\":10.983000}";
    default:
        break;
    }

}

void AsyncClient::start() { connect(); }

void AsyncClient::connect() {
    resolver_.async_resolve(host_, port_,
        [self = shared_from_this()](auto ec, auto endpoints) {
        if (!ec) {
            boost::asio::async_connect(self->socket_, endpoints,
                [self](auto ec, auto) { self->handle_connect(ec); });
        }
    });
}

void AsyncClient::handle_connect(const boost::system::error_code& ec) {
    if (!ec) 
    {
        do_write();
    }
}

void AsyncClient::do_write() {
    boost::asio::async_write(socket_, boost::asio::buffer(write_data_),
        [self = shared_from_this()](auto ec, auto bytes)
    {
        self->handle_write(ec, bytes);
    });
}

void AsyncClient::handle_write(const boost::system::error_code& ec, size_t) {
    if (!ec)
    {
        do_read();
    }
}

void AsyncClient::do_read() {
    socket_.async_read_some(boost::asio::buffer(read_buffer_),
        [self = shared_from_this()](auto ec, auto bytes)
    {
        self->handle_read(ec, bytes);
    });
}

void AsyncClient::handle_read(const boost::system::error_code& ec, size_t bytes) {
    if (!ec) 
    {
        if (std::equal(read_buffer_.data(), read_buffer_.data() + bytes, answer_data_.cbegin(), answer_data_.cend()))
        {
            if (!((thisNum = num.fetch_add(1)) % 10000))
            {
                t2 = std::chrono::high_resolution_clock::now();  
                if ((sec = std::chrono::duration_cast<std::chrono::seconds>(t2 - t1).count()) >= 60)
                {
                    if (!check.load())
                    {
                        check.store(true);
                        std::cout << thisNum <<"  "<< sec<<"s  \n";
                    }
                    return;
                }
            }
            do_write();
        }
    }
}
