#include "async_client.hpp"
#include <boost/asio.hpp>
#include <vector>
#include <memory>
#include <iostream>

int main() {
    try {
        boost::asio::io_context io;
        std::vector<std::shared_ptr<AsyncClient>> clients;
        const int clientNum{ 100 };

        for (int i = 0; i != clientNum; ++i)
        {
            auto client = std::make_shared<AsyncClient>(io, "127.0.0.1", "8085");
            client->start();
            clients.emplace_back(client);
        }

        io.run();
    }
    catch (std::exception& e) {
        std::cerr << "Exception: " << e.what() << "\n";
    }
    return 0;
}


