
#pragma once
#include <boost/asio.hpp>
#include <memory>
#include <vector>
#include <algorithm>
#include <atomic>
#include <chrono>



class AsyncClient : public std::enable_shared_from_this<AsyncClient> {
public:
    AsyncClient(boost::asio::io_context& io, const std::string& host, const std::string& port, const int testApi);
    void start();
private:
    void connect();
    void handle_connect(const boost::system::error_code& ec);
    void do_write();
    void handle_write(const boost::system::error_code& ec, size_t bytes);
    void do_read();
    void handle_read(const boost::system::error_code& ec, size_t bytes);

    boost::asio::ip::tcp::socket socket_;
    boost::asio::ip::tcp::resolver resolver_;
    std::string host_;
    std::string port_;
    std::vector<char> read_buffer_;
    std::string write_data_;
    std::string answer_data_;
    int thisNum{}, sec{};
    std::chrono::time_point<std::chrono::high_resolution_clock> t1{ std::chrono::high_resolution_clock::now() };
    std::chrono::time_point<std::chrono::high_resolution_clock> t2{ std::chrono::high_resolution_clock::now() };

};
